Action()
{
	
	web_cleanup_cookies();
	web_cache_cleanup();
	web_set_max_html_param_len("9999");
	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_start_transaction("01_Jpetstores_01_lunch");

		web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	/* Request with GET method to URL "https://petstore.octoperf.com/favicon.ico" failed during recording. Server response : 404*/

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");
	//<div id="LogoContent"><a href="/actions/Catalog.action;jsessionid={C_jsessionid}"><img src="../images/logo-topbar.gif" /></a></div>
	web_reg_save_param("C_jsessionid","LB=jsessionid=","RB=\"",LAST);

	web_url("Enter the Store", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_Jpetstores_01_lunch", LR_AUTO);


	lr_start_transaction("01_Jpetstores_02_sign_In");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

/*Correlation comment - Do not change!  Original value='8jYz91TA2THQQZe2N2xrdHtiB5cb1EPM2_SXex7tbRoPhFassSSJ-FuTHpXUWvbiygoA5HibJzkKI6vPvEYsIXi_S53gE5UOmrKR1Fl35xE=' Name ='C_sourcePage' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=C_sourcePage",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\"",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

/*Correlation comment - Do not change!  Original value='Ae_EYAL-pfAxKyg9dpA814t19mgf8Gok3eCC42-beAb3GtciGgPt3ZOTeluLY4tg' Name ='C_fp_value' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=C_fp_value",
		"LB=name=\"__fp\" value=\"",
		"RB=\"",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_url("Sign In", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid={C_jsessionid}?signonForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_submit_data("Account.action",
		"Action=https://petstore.octoperf.com/actions/Account.action",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid={C_jsessionid}?signonForm=",
		"Snapshot=t25.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={P_username}", ENDITEM,
		"Name=password", "Value={P_password}", ENDITEM,
		"Name=signon", "Value=Login", ENDITEM,
		"Name=_sourcePage", "Value={C_sourcePage}", ENDITEM,
		"Name=__fp", "Value={C_fp_value}", ENDITEM,
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	lr_end_transaction("01_Jpetstores_02_sign_In",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_03_select_pet");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("sm_fish.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=FISH", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_end_transaction("01_Jpetstores_03_select_pet",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_04_select_breed");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_url("FI-SW-02", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=FI-SW-02", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId=FISH", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_Jpetstores_04_select_breed",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_05_add_to_cart");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_url("Add to Cart", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-3", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId=FI-SW-02", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_Jpetstores_05_add_to_cart",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_06_clickon_proceed_to_checkout");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

/*Correlation comment - Do not change!  Original value='cZahpOUOkV4hNObfVvlgvHlyxjLJWjSNKswo86HoTgXvrlE9vIUQXuRvhUeeRRvc4IZh2kxMc9A0tzfCUySZAWqMZeGtWRUzF_sXbd85rOc=' Name ='C_sourcePage_1' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=C_sourcePage_1",
		"LB=name=\"_sourcePage\" value=\"",
		"RB=\"",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

/*Correlation comment - Do not change!  Original value='q2UUGnR6EoQazdP8Hyck0_ACF6q_vDyZ4XPsTTbVvCNX7vQhpK1fi2GnU0fGOnQeboGPgWAvzjfEQG_fcn7v9Tgy-5QButtj5xBDrmFCdczMnRjhLlKqkA==' Name ='C_fp_1' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=C_fp_1",
		"LB=name=\"__fp\" value=\"",
		"RB=\"",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_url("Proceed to Checkout", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrderForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-3", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	lr_end_transaction("01_Jpetstores_06_clickon_proceed_to_checkout",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_07_payment_details");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_add_header("Origin", 
		"https://petstore.octoperf.com");

	web_submit_data("Order.action",
		"Action=https://petstore.octoperf.com/actions/Order.action",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrderForm=",
		"Snapshot=t30.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=order.cardType", "Value=Visa", ENDITEM,
		"Name=order.creditCard", "Value=999 9999 9999 9999", ENDITEM,
		"Name=order.expiryDate", "Value=12/03", ENDITEM,
		"Name=order.billToFirstName", "Value={P_firtsname}", ENDITEM,
		"Name=order.billToLastName", "Value={P_lastname}", ENDITEM,
		"Name=order.billAddress1", "Value=1-64/1", ENDITEM,
		"Name=order.billAddress2", "Value=", ENDITEM,
		"Name=order.billCity", "Value=hyderabad", ENDITEM,
		"Name=order.billState", "Value=TN", ENDITEM,
		"Name=order.billZip", "Value=530007", ENDITEM,
		"Name=order.billCountry", "Value=IN", ENDITEM,
		"Name=newOrder", "Value=Continue", ENDITEM,
		"Name=_sourcePage", "Value={C_sourcePage_1}", ENDITEM,
		"Name=__fp", "Value={C_fp_1}", ENDITEM,
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_end_transaction("01_Jpetstores_07_payment_details",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_08_click_on_confirm");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_url("Confirm", 
		"URL=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_Jpetstores_08_click_on_confirm",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("01_Jpetstores_09_sign_out");

	web_reg_find("Text=JPetStore Demo", 
		LAST);

	web_url("Sign Out", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signoff=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Order.action?newOrder=&confirmed=true", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("01_Jpetstores_09_sign_out",LR_AUTO);

	lr_think_time(3);

	return 0;
}