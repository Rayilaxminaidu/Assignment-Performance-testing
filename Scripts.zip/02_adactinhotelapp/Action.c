Action()
{
	long file;
	char *fName = "C:\\Tool\\OrderID.txt";
	
	web_cleanup_cookies();
	web_cache_cleanup();
	web_set_max_html_param_len("9999");
	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_start_transaction("02_adactinhotelapp_01_lunch");

		web_reg_find("Text=Adactin.com - Hotel Reservation System","SaveCount=lunch",
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("adactinhotelapp.com", 
		"URL=https://adactinhotelapp.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("02_adactinhotelapp_01_lunch", LR_AUTO);


	/* Request with GET method to URL "https://adactinhotelapp.com/favicon.ico" failed during recording. Server response : 404*/

	lr_start_transaction("02_adactinhotelapp_02_login");

	web_reg_find("Text=Adactin.com - Search Hotel", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Origin", 
		"https://adactinhotelapp.com");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_submit_data("adactinhotelapp.com_2", 
		"Action=https://adactinhotelapp.com/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://adactinhotelapp.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=username", "Value={P_Username}", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		"Name=login", "Value=Login", ENDITEM, 
		LAST);

	lr_end_transaction("02_adactinhotelapp_02_login",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("02_adactinhotelapp_03_search_hotel");

	web_reg_find("Text=Adactin.com - Select Hotel", 
		LAST);

	web_revert_auto_header("Origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("SelectHotel.php", 
		"Action=https://adactinhotelapp.com/SelectHotel.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://adactinhotelapp.com/SearchHotel.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=location", "Value=London", ENDITEM, 
		"Name=hotels", "Value=", ENDITEM, 
		"Name=room_type", "Value=", ENDITEM, 
		"Name=room_nos", "Value=1", ENDITEM, 
		"Name=datepick_in", "Value=07/10/2023", ENDITEM, 
		"Name=datepick_out", "Value=08/10/2023", ENDITEM, 
		"Name=adult_room", "Value=1", ENDITEM, 
		"Name=child_room", "Value=0", ENDITEM, 
		"Name=Submit", "Value=Search", ENDITEM, 
		"Name=datepick_diff", "Value=1", ENDITEM, 
		LAST);

	lr_end_transaction("02_adactinhotelapp_03_search_hotel",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("02_adactinhotelapp_04_select_hotel");

	web_reg_find("Text=Adactin.com - Book A Hotel", 
		LAST);

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Origin", 
		"https://adactinhotelapp.com");

	web_submit_data("BookHotel.php", 
		"Action=https://adactinhotelapp.com/BookHotel.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://adactinhotelapp.com/SelectHotel.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=total_radiobutton", "Value=4", ENDITEM, 
		"Name=hotel_name_1", "Value=Hotel Cornice", ENDITEM, 
		"Name=location_1", "Value=London", ENDITEM, 
		"Name=rooms_1", "Value=1 Rooms", ENDITEM, 
		"Name=arr_date_1", "Value=07/10/2023", ENDITEM, 
		"Name=dep_date_1", "Value=08/10/2023", ENDITEM, 
		"Name=no_days_1", "Value=1 Days", ENDITEM, 
		"Name=room_type_1", "Value=Standard", ENDITEM, 
		"Name=price_night_1", "Value=AUD $ 100", ENDITEM, 
		"Name=total_price_1", "Value=AUD $ 110", ENDITEM, 
		"Name=hotel_name_2", "Value=Hotel Creek", ENDITEM, 
		"Name=location_2", "Value=London", ENDITEM, 
		"Name=rooms_2", "Value=1 Rooms", ENDITEM, 
		"Name=arr_date_2", "Value=07/10/2023", ENDITEM, 
		"Name=dep_date_2", "Value=08/10/2023", ENDITEM, 
		"Name=no_days_2", "Value=1 Days", ENDITEM, 
		"Name=room_type_2", "Value=Standard", ENDITEM, 
		"Name=price_night_2", "Value=AUD $ 125", ENDITEM, 
		"Name=total_price_2", "Value=AUD $ 135", ENDITEM, 
		"Name=radiobutton_3", "Value=3", ENDITEM, 
		"Name=hotel_name_3", "Value=Hotel Hervey", ENDITEM, 
		"Name=location_3", "Value=London", ENDITEM, 
		"Name=rooms_3", "Value=1 Rooms", ENDITEM, 
		"Name=arr_date_3", "Value=07/10/2023", ENDITEM, 
		"Name=dep_date_3", "Value=08/10/2023", ENDITEM, 
		"Name=no_days_3", "Value=1 Days", ENDITEM, 
		"Name=room_type_3", "Value=Standard", ENDITEM, 
		"Name=price_night_3", "Value=AUD $ 150", ENDITEM, 
		"Name=total_price_3", "Value=AUD $ 160", ENDITEM, 
		"Name=hotel_name_4", "Value=Hotel Sunshine", ENDITEM, 
		"Name=location_4", "Value=London", ENDITEM, 
		"Name=rooms_4", "Value=1 Rooms", ENDITEM, 
		"Name=arr_date_4", "Value=07/10/2023", ENDITEM, 
		"Name=dep_date_4", "Value=08/10/2023", ENDITEM, 
		"Name=no_days_4", "Value=1 Days", ENDITEM, 
		"Name=room_type_4", "Value=Standard", ENDITEM, 
		"Name=price_night_4", "Value=AUD $ 175", ENDITEM, 
		"Name=total_price_4", "Value=AUD $ 185", ENDITEM, 
		"Name=continue", "Value=Continue", ENDITEM, 
		"Name=hotel_name", "Value=Hotel Hervey", ENDITEM, 
		"Name=location_name", "Value=London", ENDITEM, 
		"Name=room_types", "Value=Standard", ENDITEM, 
		"Name=rooms_no", "Value=1", ENDITEM, 
		"Name=arr_date", "Value=07/10/2023", ENDITEM, 
		"Name=dep_date", "Value=08/10/2023", ENDITEM, 
		"Name=no_days", "Value=1", ENDITEM, 
		"Name=adults_room", "Value=1", ENDITEM, 
		"Name=children_room", "Value=0", ENDITEM, 
		"Name=price_night", "Value=AUD $ 150", ENDITEM, 
		"Name=total_price", "Value=AUD $ 160", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	lr_end_transaction("02_adactinhotelapp_04_select_hotel",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("02_adactinhotelapp_05_booking_confirm");

		web_reg_find("Text=Adactin.com - Hotel Booking Confirmation", 
		LAST);

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");
	web_reg_save_param("C_OrderID","LB=class=\"disable_text\" id=\"order_no\" value=\"","RB=\" disabled=\"disabled\" />",LAST);

	web_submit_data("BookingConfirm.php", 
		"Action=https://adactinhotelapp.com/BookingConfirm.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://adactinhotelapp.com/BookHotel.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=first_name", "Value={P_Firstname}", ENDITEM, 
		"Name=last_name", "Value={P_Lastname}", ENDITEM, 
		"Name=address", "Value={P_Address}", ENDITEM, 
		"Name=cc_num", "Value={P_Cardnumber}", ENDITEM, 
		"Name=cc_type", "Value=MAST", ENDITEM, 
		"Name=cc_exp_month", "Value={P_Card_expairymonth}", ENDITEM, 
		"Name=cc_exp_year", "Value={P_Card_expiryyear}", ENDITEM, 
		"Name=cc_cvv", "Value={P_Card_cvv}", ENDITEM, 
		"Name=hotel_name_hid", "Value=Hotel Hervey", ENDITEM, 
		"Name=location_name_hid", "Value=London", ENDITEM, 
		"Name=room_types_hid", "Value=Standard", ENDITEM, 
		"Name=rooms_no_hid", "Value=1", ENDITEM, 
		"Name=arr_date_hid", "Value=07/10/2023", ENDITEM, 
		"Name=dep_date_hid", "Value=08/10/2023", ENDITEM, 
		"Name=no_days_hid", "Value=1", ENDITEM, 
		"Name=adults_room_hid", "Value=1", ENDITEM, 
		"Name=children_room_hid", "Value=0", ENDITEM, 
		"Name=price_night_hid", "Value=AUD $ 150", ENDITEM, 
		"Name=total_price_hid", "Value=AUD $ 160", ENDITEM, 
		"Name=gst_hid", "Value=AUD $ 16", ENDITEM, 
		"Name=final_price_hid", "Value=AUD $ 176", ENDITEM, 
		LAST);

	lr_end_transaction("02_adactinhotelapp_05_booking_confirm", LR_AUTO);


	lr_start_transaction("02_adactinhotelapp_06_logout");

	web_revert_auto_header("Origin");

	web_reg_find("Text=Adactin.com - Logout", 
		LAST);

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_url("Logout", 
		"URL=https://adactinhotelapp.com/Logout.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://adactinhotelapp.com/BookingConfirm.php", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("02_adactinhotelapp_06_logout",LR_AUTO);

	lr_think_time(3);
	
	file = fopen(fName,"a");
	fprintf(file,"%s \n",lr_eval_string("{C_OrderID}"));
	fclose(file);

	return 0;
}